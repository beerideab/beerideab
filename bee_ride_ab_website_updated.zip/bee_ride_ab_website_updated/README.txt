BEE RIDE AB — UPDATED WEBSITE

Included:
- index.html: responsive Swedish/English taxi website
- Phone link and WhatsApp link
- Email contact link
- Free hosting instructions

Contact details included:
- Swedish phone: 0700 530 187
- International phone / WhatsApp: +46 70 053 01 87
- Email: sarwaralianjum@gmail.com

FREE PUBLISHING WITH GITHUB PAGES
1. Download and unzip bee_ride_ab_website_updated.zip.
2. Sign in or create a free account at https://github.com.
3. Create a new PUBLIC repository named bee-ride-ab.
4. Upload index.html from this folder to the repository root. You may also upload this README.
5. Open the repository's Settings tab.
6. In the left menu, choose Pages.
7. Under Build and deployment, choose Deploy from a branch.
8. Select branch main and folder /(root), then Save.
9. Wait for deployment. GitHub Pages will show the published website address in Settings → Pages. It will typically resemble:
   https://YOUR-USERNAME.github.io/bee-ride-ab/

NOTES
- GitHub Pages hosting is free for public repositories, subject to GitHub's current terms and limits.
- A custom .se or .com domain normally costs extra.
- This is a contact-based website, not an online dispatch or payment system.
- Before publishing, confirm the business contact details and that the advertised services match your actual operation.
